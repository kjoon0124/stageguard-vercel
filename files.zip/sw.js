// StageGuard 최소 서비스 워커
// 앱 본체(Streamlit)는 항상 온라인으로 불러오므로 캐시하지 않고 네트워크로 그대로 통과시킵니다.
// (fetch 핸들러가 있어야 일부 브라우저에서 '앱 설치'가 가능합니다.)
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (event) => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', (event) => {
  event.respondWith(fetch(event.request));
});
